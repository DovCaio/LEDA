package sorting.divideAndConquer.quicksort3;

public class TestandoFuncionalidades {

	public static void main(String[] args) {
		
		QuickSortMedianOfThree qsmt = new QuickSortMedianOfThree<>();
		
		Integer[] array = criarArray();
		
		qsmt.sort(array, 0 , 19);
		
		for(Integer numero : array) {
			System.out.println(numero);
		}
		
		
	}
	
	
	
	public static Integer[] criarArray() {
		Integer[] array = new Integer[20];
		
		array[0] = 12;
		array[1] = 51;
		array[2] = 42;
		array[3] = 12;
		array[4] = 1;
		array[5] = 124;
		array[6] = 512;
		array[7] = 346;
		array[8] = 765;
		array[9] = 1;
		array[10] = 42;
		array[11] = 54554;
		array[12] = 912;
		array[13] = 4;
		array[14] = 1;
		array[15] = 252;
		array[16] = 0;
		array[17] = 12312;
		array[18] = 9922;
		array[19] = 5;
		
		return array;
	}
	
}
